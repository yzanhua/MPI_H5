#ifndef RANDOM_WALKING_H_
#define RANDOM_WALKING_H_
namespace random_walk {

struct Walker {
    int location;
    int num_steps_left_in_walk;
};

}
#endif // RANDOM_WALKING_H_
