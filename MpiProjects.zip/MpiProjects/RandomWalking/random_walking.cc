#include "random_walking.h"

#include <iostream>
#include <mpi.h>
#include <vector>

using std::vector;

namespace random_walk
{
    void DecomposeDomain(int domain_size, int this_rank, int world_size, int *subdomain_start, int *subdomain_size)
    {
        if (world_size > domain_size)
        {
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        
        *subdomain_size = domain_size / world_size;
        *subdomain_start = domain_size / world_size * this_rank;

        if (this_rank == world_size - 1)
        {
            *subdomain_size += domain_size % world_size;
        }
    }

    void InitializeWalkers(int num_walkers_per_proc, int max_walk_size, int subdomain_start, int subdomain_size,
                           vector<Walker> *incoming_walkers)
    {
        Walker walker;
        for (int i = 0; i < num_walkers_per_proc; i++)
        {
            walker.location = subdomain_start;
            walker.num_steps_left_in_walk = (rand() / (float)RAND_MAX) * max_walk_size;
            incoming_walkers->push_back(walker);
        }
    }

}